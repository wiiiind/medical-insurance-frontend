<template>
  <div class="admission-registration">
    <h2>入院登记</h2>
    <p>这里将是患者入院登记的表单。</p>
    <form>
      <div class="mb-3">
        <label for="patientName" class="form-label">患者姓名</label>
        <input type="text" class="form-control" id="patientName" placeholder="请输入患者姓名">
      </div>
      <div class="mb-3">
        <label for="patientId" class="form-label">身份证号</label>
        <input type="text" class="form-control" id="patientId" placeholder="请输入身份证号">
      </div>
      <div class="mb-3">
        <label for="admissionDate" class="form-label">入院日期</label>
        <input type="date" class="form-control" id="admissionDate">
      </div>
      <button type="submit" class="btn btn-primary">提交</button>
    </form>
  </div>
</template>

<script>
export default {
  name: 'AdmissionRegistration'
}
</script>

<style scoped>
.admission-registration {
  padding: 20px;
}
</style>