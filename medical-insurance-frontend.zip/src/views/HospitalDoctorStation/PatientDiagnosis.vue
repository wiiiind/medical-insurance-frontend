<template>
  <div class="patient-diagnosis">
    <h2>患者诊断</h2>
    <p>这里将是患者诊断的页面。</p>

    <ul class="nav nav-tabs" id="diagnosisTab" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link active" id="admission-diagnosis-tab" data-bs-toggle="tab" data-bs-target="#admission-diagnosis" type="button" role="tab" aria-controls="admission-diagnosis" aria-selected="true">入院诊断</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="main-diagnosis-tab" data-bs-toggle="tab" data-bs-target="#main-diagnosis" type="button" role="tab" aria-controls="main-diagnosis" aria-selected="false">主要诊断</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="other-diagnosis-tab" data-bs-toggle="tab" data-bs-target="#other-diagnosis" type="button" role="tab" aria-controls="other-diagnosis" aria-selected="false">其他诊断</button>
      </li>
    </ul>
    <div class="tab-content" id="diagnosisTabContent">
      <div class="tab-pane fade show active" id="admission-diagnosis" role="tabpanel" aria-labelledby="admission-diagnosis-tab">
        <h4 class="mt-3">入院诊断</h4>
        <p>这里是入院诊断的内容。</p>
        <!-- 诊断列表和添加表单 -->
      </div>
      <div class="tab-pane fade" id="main-diagnosis" role="tabpanel" aria-labelledby="main-diagnosis-tab">
        <h4 class="mt-3">主要诊断</h4>
        <p>这里是主要诊断的内容。</p>
      </div>
      <div class="tab-pane fade" id="other-diagnosis" role="tabpanel" aria-labelledby="other-diagnosis-tab">
        <h4 class="mt-3">其他诊断</h4>
        <p>这里是其他诊断的内容。</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PatientDiagnosis'
}
</script>

<style scoped>
.patient-diagnosis {
  padding: 20px;
}
</style>