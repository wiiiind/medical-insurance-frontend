<template>
  <div class="patient-orders">
    <h2>患者医嘱</h2>
    <p>这里将是患者医嘱的页面。</p>

    <ul class="nav nav-tabs" id="ordersTab" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link active" id="drug-order-tab" data-bs-toggle="tab" data-bs-target="#drug-order" type="button" role="tab" aria-controls="drug-order" aria-selected="true">药品医嘱</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="treatment-order-tab" data-bs-toggle="tab" data-bs-target="#treatment-order" type="button" role="tab" aria-controls="treatment-order" aria-selected="false">诊疗项目医嘱</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="medical-service-order-tab" data-bs-toggle="tab" data-bs-target="#medical-service-order" type="button" role="tab" aria-controls="medical-service-order" aria-selected="false">医疗服务医嘱</button>
      </li>
    </ul>
    <div class="tab-content" id="ordersTabContent">
      <div class="tab-pane fade show active" id="drug-order" role="tabpanel" aria-labelledby="drug-order-tab">
        <h4 class="mt-3">药品医嘱</h4>
        <p>这里是药品医嘱的内容。</p>
        <!-- 药品列表和添加表单 -->
      </div>
      <div class="tab-pane fade" id="treatment-order" role="tabpanel" aria-labelledby="treatment-order-tab">
        <h4 class="mt-3">诊疗项目医嘱</h4>
        <p>这里是诊疗项目医嘱的内容。</p>
      </div>
      <div class="tab-pane fade" id="medical-service-order" role="tabpanel" aria-labelledby="medical-service-order-tab">
        <h4 class="mt-3">医疗服务医嘱</h4>
        <p>这里是医疗服务医嘱的内容。</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PatientOrders'
}
</script>

<style scoped>
.patient-orders {
  padding: 20px;
}
</style>