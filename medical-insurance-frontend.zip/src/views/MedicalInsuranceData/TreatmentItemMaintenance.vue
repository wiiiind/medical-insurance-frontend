<template>
  <div class="treatment-item-maintenance">
    <h2>诊疗项目数据维护</h2>
    <p>这里将展示诊疗项目数据的表格，并提供增删改查功能。</p>
    <!-- 诊疗项目数据表格 -->
    <table class="table table-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>项目名称</th>
          <th>项目编码</th>
          <th>价格</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <!-- 示例数据 -->
        <tr>
          <td>1</td>
          <td>血常规</td>
          <td>JC001</td>
          <td>20.00</td>
          <td>
            <button class="btn btn-sm btn-primary me-2">修改</button>
            <button class="btn btn-sm btn-danger">删除</button>
          </td>
        </tr>
        <tr>
          <td>2</td>
          <td>尿常规</td>
          <td>JC002</td>
          <td>15.00</td>
          <td>
            <button class="btn btn-sm btn-primary me-2">修改</button>
            <button class="btn btn-sm btn-danger">删除</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- 增删改查按钮 -->
    <div class="mt-3">
      <button class="btn btn-success me-2">新增项目</button>
      <button class="btn btn-info">刷新</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'TreatmentItemMaintenance'
}
</script>

<style scoped>
.treatment-item-maintenance {
  padding: 20px;
}
</style>