<template>
  <div class="medical-service-maintenance">
    <h2>医疗服务设施数据维护</h2>
    <p>这里将展示医疗服务设施数据的表格，并提供增删改查功能。</p>
    <!-- 医疗服务设施数据表格 -->
    <table class="table table-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>服务名称</th>
          <th>服务编码</th>
          <th>价格</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <!-- 示例数据 -->
        <tr>
          <td>1</td>
          <td>挂号费</td>
          <td>FW001</td>
          <td>5.00</td>
          <td>
            <button class="btn btn-sm btn-primary me-2">修改</button>
            <button class="btn btn-sm btn-danger">删除</button>
          </td>
        </tr>
        <tr>
          <td>2</td>
          <td>床位费</td>
          <td>FW002</td>
          <td>30.00</td>
          <td>
            <button class="btn btn-sm btn-primary me-2">修改</button>
            <button class="btn btn-sm btn-danger">删除</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- 增删改查按钮 -->
    <div class="mt-3">
      <button class="btn btn-success me-2">新增服务</button>
      <button class="btn btn-info">刷新</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MedicalServiceMaintenance'
}
</script>

<style scoped>
.medical-service-maintenance {
  padding: 20px;
}
</style>