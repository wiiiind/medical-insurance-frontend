<template>
  <div class="drug-maintenance">
    <h2>医保药品数据维护</h2>
    <p>这里将展示医保药品数据的表格，并提供增删改查功能。</p>

    <!-- 新增/编辑药品模态框 -->
    <div class="modal fade" id="drugModal" tabindex="-1" aria-labelledby="drugModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="drugModalLabel">{{ isEditing ? '编辑药品' : '新增药品' }}</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form>
              <div class="mb-3">
                <label for="drugName" class="form-label">药品名称</label>
                <input type="text" class="form-control" id="drugName" v-model="currentDrug.name">
              </div>
              <div class="mb-3">
                <label for="drugSpec" class="form-label">规格</label>
                <input type="text" class="form-control" id="drugSpec" v-model="currentDrug.spec">
              </div>
              <div class="mb-3">
                <label for="drugManufacturer" class="form-label">生产企业</label>
                <input type="text" class="form-control" id="drugManufacturer" v-model="currentDrug.manufacturer">
              </div>
              <div class="mb-3">
                <label for="drugPrice" class="form-label">价格</label>
                <input type="number" class="form-control" id="drugPrice" v-model="currentDrug.price">
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
            <button type="button" class="btn btn-primary" @click="saveDrug">保存</button>
          </div>
        </div>
      </div>
    </div>

    <!-- 药品数据表格 -->
    <table class="table table-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>药品名称</th>
          <th>规格</th>
          <th>生产企业</th>
          <th>价格</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(drug, index) in drugs" :key="drug.id">
          <td>{{ index + 1 }}</td>
          <td>{{ drug.name }}</td>
          <td>{{ drug.spec }}</td>
          <td>{{ drug.manufacturer }}</td>
          <td>{{ drug.price.toFixed(2) }}</td>
          <td>
            <button class="btn btn-sm btn-primary me-2" @click="editDrug(drug)">修改</button>
            <button class="btn btn-sm btn-danger" @click="deleteDrug(drug.id)">删除</button>
          </td>
        </tr>
        <tr v-if="drugs.length === 0">
          <td colspan="6" class="text-center">暂无药品数据</td>
        </tr>
      </tbody>
    </table>

    <!-- 增删改查按钮 -->
    <div class="mt-3">
      <button class="btn btn-success me-2" @click="showAddModal">新增药品</button>
      <button class="btn btn-info" @click="fetchDrugs">刷新</button>
    </div>
  </div>
</template>

<script>
import { Modal } from 'bootstrap'

export default {
  name: 'DrugMaintenance',
  data() {
    return {
      drugs: [],
      currentDrug: {
        id: null,
        name: '',
        spec: '',
        manufacturer: '',
        price: 0
      },
      isEditing: false,
      drugModal: null
    }
  },
  mounted() {
    this.fetchDrugs()
    this.drugModal = new Modal(document.getElementById('drugModal'))
  },
  methods: {
    fetchDrugs() {
      // 模拟从后端获取数据
      console.log('模拟：正在获取药品数据...')
      setTimeout(() => {
        this.drugs = [
          { id: 1, name: '阿莫西林胶囊', spec: '0.25g*24粒', manufacturer: '华北制药', price: 12.50 },
          { id: 2, name: '布洛芬缓释胶囊', spec: '0.3g*10粒', manufacturer: '中美史克', price: 8.80 },
          { id: 3, name: '感冒灵颗粒', spec: '10g*9袋', manufacturer: '白云山', price: 15.00 }
        ]
        console.log('模拟：药品数据获取成功！')
      }, 500)
      // 实际API调用示例：
      // axios.get('/api/drugs')
      //   .then(response => {
      //     this.drugs = response.data
      //   })
      //   .catch(error => {
      //     console.error('获取药品数据失败:', error)
      //   })
    },
    showAddModal() {
      this.isEditing = false
      this.currentDrug = {
        id: null,
        name: '',
        spec: '',
        manufacturer: '',
        price: 0
      }
      this.drugModal.show()
    },
    editDrug(drug) {
      this.isEditing = true
      this.currentDrug = { ...drug }
      this.drugModal.show()
    },
    saveDrug() {
      if (this.isEditing) {
        // 模拟更新药品
        console.log('模拟：正在更新药品...', this.currentDrug)
        setTimeout(() => {
          const index = this.drugs.findIndex(d => d.id === this.currentDrug.id)
          if (index !== -1) {
            this.drugs.splice(index, 1, { ...this.currentDrug })
          }
          this.drugModal.hide()
          console.log('模拟：药品更新成功！')
        }, 500)
        // 实际API调用示例：
        // axios.put(`/api/drugs/${this.currentDrug.id}`, this.currentDrug)
        //   .then(() => {
        //     this.fetchDrugs()
        //     this.drugModal.hide()
        //   })
        //   .catch(error => {
        //     console.error('更新药品失败:', error)
        //   })
      } else {
        // 模拟新增药品
        console.log('模拟：正在新增药品...', this.currentDrug)
        setTimeout(() => {
          const newId = Math.max(...this.drugs.map(d => d.id)) + 1 || 1
          this.drugs.push({ ...this.currentDrug, id: newId })
          this.drugModal.hide()
          console.log('模拟：药品新增成功！')
        }, 500)
        // 实际API调用示例：
        // axios.post('/api/drugs', this.currentDrug)
        //   .then(() => {
        //     this.fetchDrugs()
        //     this.drugModal.hide()
        //   })
        //   .catch(error => {
        //     console.error('新增药品失败:', error)
        //   })
      }
    },
    deleteDrug(id) {
      if (confirm('确定要删除该药品吗？')) {
        // 模拟删除药品
        console.log('模拟：正在删除药品...', id)
        setTimeout(() => {
          this.drugs = this.drugs.filter(drug => drug.id !== id)
          console.log('模拟：药品删除成功！')
        }, 500)
        // 实际API调用示例：
        // axios.delete(`/api/drugs/${id}`)
        //   .then(() => {
        //     this.fetchDrugs()
        //   })
        //   .catch(error => {
        //     console.error('删除药品失败:', error)
        //   })
      }
    }
  }
}
</script>

<style scoped>
.drug-maintenance {
  padding: 20px;
}
</style>