<template>
  <div class="drug-reimbursement-ratio-maintenance">
    <h2>药品报销比例维护</h2>
    <p>这里将展示药品报销比例的表格，并提供增删改查功能。</p>
    <!-- 药品报销比例数据表格 -->
    <table class="table table-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>药品类别</th>
          <th>报销比例</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <!-- 示例数据 -->
        <tr>
          <td>1</td>
          <td>甲类</td>
          <td>80%</td>
          <td>
            <button class="btn btn-sm btn-primary me-2">修改</button>
            <button class="btn btn-sm btn-danger">删除</button>
          </td>
        </tr>
        <tr>
          <td>2</td>
          <td>乙类</td>
          <td>70%</td>
          <td>
            <button class="btn btn-sm btn-primary me-2">修改</button>
            <button class="btn btn-sm btn-danger">删除</button>
          </td>
        </tr>
        <tr>
          <td>3</td>
          <td>丙类</td>
          <td>0%</td>
          <td>
            <button class="btn btn-sm btn-primary me-2">修改</button>
            <button class="btn btn-sm btn-danger">删除</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- 增删改查按钮 -->
    <div class="mt-3">
      <button class="btn btn-success me-2">新增比例</button>
      <button class="btn btn-info">刷新</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'DrugReimbursementRatioMaintenance'
}
</script>

<style scoped>
.drug-reimbursement-ratio-maintenance {
  padding: 20px;
}
</style>