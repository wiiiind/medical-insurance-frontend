<template>
  <div class="hospital-reimbursement-ratio-maintenance">
    <h2>医院报销比例维护</h2>
    <p>这里将展示不同等级医院的报销比例，并提供增删改查功能。</p>

    <ul class="nav nav-tabs" id="myTab" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link active" id="tier1-tab" data-bs-toggle="tab" data-bs-target="#tier1" type="button" role="tab" aria-controls="tier1" aria-selected="true">一级医院</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="tier2-tab" data-bs-toggle="tab" data-bs-target="#tier2" type="button" role="tab" aria-controls="tier2" aria-selected="false">二级医院</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="tier3-tab" data-bs-toggle="tab" data-bs-target="#tier3" type="button" role="tab" aria-controls="tier3" aria-selected="false">三级医院</button>
      </li>
    </ul>
    <div class="tab-content" id="myTabContent">
      <div class="tab-pane fade show active" id="tier1" role="tabpanel" aria-labelledby="tier1-tab">
        <h4 class="mt-3">一级医院报销比例</h4>
        <table class="table table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>人员类别</th>
              <th>起付线</th>
              <th>等级线</th>
              <th>报销比例</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <!-- 示例数据 -->
            <tr>
              <td>1</td>
              <td>在职</td>
              <td>100</td>
              <td>5000</td>
              <td>70%</td>
              <td>
                <button class="btn btn-sm btn-primary me-2">修改</button>
                <button class="btn btn-sm btn-danger">删除</button>
              </td>
            </tr>
            <tr>
              <td>2</td>
              <td>退休</td>
              <td>50</td>
              <td>5000</td>
              <td>80%</td>
              <td>
                <button class="btn btn-sm btn-primary me-2">修改</button>
                <button class="btn btn-sm btn-danger">删除</button>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="mt-3">
          <button class="btn btn-success me-2">新增比例</button>
          <button class="btn btn-info">刷新</button>
        </div>
      </div>
      <div class="tab-pane fade" id="tier2" role="tabpanel" aria-labelledby="tier2-tab">
        <h4 class="mt-3">二级医院报销比例</h4>
        <table class="table table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>人员类别</th>
              <th>起付线</th>
              <th>等级线</th>
              <th>报销比例</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <!-- 示例数据 -->
            <tr>
              <td>1</td>
              <td>在职</td>
              <td>200</td>
              <td>10000</td>
              <td>60%</td>
              <td>
                <button class="btn btn-sm btn-primary me-2">修改</button>
                <button class="btn btn-sm btn-danger">删除</button>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="mt-3">
          <button class="btn btn-success me-2">新增比例</button>
          <button class="btn btn-info">刷新</button>
        </div>
      </div>
      <div class="tab-pane fade" id="tier3" role="tabpanel" aria-labelledby="tier3-tab">
        <h4 class="mt-3">三级医院报销比例</h4>
        <table class="table table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>人员类别</th>
              <th>起付线</th>
              <th>等级线</th>
              <th>报销比例</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <!-- 示例数据 -->
            <tr>
              <td>1</td>
              <td>在职</td>
              <td>300</td>
              <td>15000</td>
              <td>50%</td>
              <td>
                <button class="btn btn-sm btn-primary me-2">修改</button>
                <button class="btn btn-sm btn-danger">删除</button>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="mt-3">
          <button class="btn btn-success me-2">新增比例</button>
          <button class="btn btn-info">刷新</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HospitalReimbursementRatioMaintenance'
}
</script>

<style scoped>
.hospital-reimbursement-ratio-maintenance {
  padding: 20px;
}
</style>