<template>
  <div>
    <h2>医保药品数据维护</h2>
    <!-- 搜索和新增按钮 -->
    <div class="d-flex justify-content-between mb-3">
      <div class="d-flex">
        <input type="text" class="form-control" placeholder="按药品名称搜索..." v-model="searchQuery">
        <button class="btn btn-primary ms-2" @click="fetchDrugs">搜索</button>
      </div>
      <button class="btn btn-success" @click="openAddModal">新增药品</button>
    </div>

    <!-- 药品列表 -->
    <table class="table table-striped">
      <thead>
        <tr>
          <th>药品分类</th>
          <th>药品中文名称</th>
          <th>规格</th>
          <th>生产企业</th>
          <th>价格</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="drug in drugs" :key="drug.id">
          <td>{{ drug.category }}</td>
          <td>{{ drug.name }}</td>
          <td>{{ drug.spec }}</td>
          <td>{{ drug.manufacturer }}</td>
          <td>{{ drug.price }}</td>
          <td>
            <button class="btn btn-sm btn-warning me-2" @click="openEditModal(drug)">修改</button>
            <button class="btn btn-sm btn-danger" @click="handleDeleteDrug(drug.id)">删除</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- 新增/修改模态框 -->
    <div v-if="showModal" class="modal fade show d-block" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">{{ isEditMode ? '修改药品' : '新增药品' }}</h5>
            <button type="button" class="btn-close" @click="closeModal"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="handleSaveDrug">
              <div class="mb-3">
                <label class="form-label">药品分类</label>
                <input type="text" class="form-control" v-model="currentDrug.category" required>
              </div>
              <div class="mb-3">
                <label class="form-label">药品中文名称</label>
                <input type="text" class="form-control" v-model="currentDrug.name" required>
              </div>
              <div class="mb-3">
                <label class="form-label">规格</label>
                <input type="text" class="form-control" v-model="currentDrug.spec">
              </div>
              <div class="mb-3">
                <label class="form-label">生产企业</label>
                <input type="text" class="form-control" v-model="currentDrug.manufacturer">
              </div>
              <div class="mb-3">
                <label class="form-label">价格</label>
                <input type="number" class="form-control" v-model="currentDrug.price" required>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" @click="closeModal">关闭</button>
                <button type="submit" class="btn btn-primary">保存</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from '@/api';

export default {
  name: 'DrugMaintenance',
  data() {
    return {
      searchQuery: '',
      drugs: [],
      showModal: false,
      isEditMode: false,
      currentDrug: {
        id: null,
        category: '',
        name: '',
        spec: '',
        manufacturer: '',
        price: 0,
      },
    };
  },
  created() {
    this.fetchDrugs();
  },
  methods: {
    async fetchDrugs() {
      try {
        const response = await api.get('/drugs', {
          params: { name: this.searchQuery }
        });
        this.drugs = response.data;
      } catch (error) {
        console.error('获取药品列表失败:', error);
        alert('获取药品列表失败');
      }
    },
    openAddModal() {
      this.isEditMode = false;
      this.currentDrug = { id: null, category: '', name: '', spec: '', manufacturer: '', price: 0 };
      this.showModal = true;
    },
    openEditModal(drug) {
      this.isEditMode = true;
      this.currentDrug = { ...drug };
      this.showModal = true;
    },
    closeModal() {
      this.showModal = false;
    },
    async handleSaveDrug() {
      try {
        if (this.isEditMode) {
          await api.put(`/drugs/${this.currentDrug.id}`, this.currentDrug);
        } else {
          await api.post('/drugs', this.currentDrug);
        }
        this.closeModal();
        this.fetchDrugs(); // Refresh list
      } catch (error) {
        console.error('保存药品失败:', error);
        alert('保存药品失败');
      }
    },
    async handleDeleteDrug(id) {
      if (confirm('确定要删除该药品吗？')) {
        try {
          await api.delete(`/drugs/${id}`);
          this.fetchDrugs(); // Refresh list
        } catch (error) {
          console.error('删除药品失败:', error);
          alert('删除药品失败');
        }
      }
    },
  },
};
</script>

<style scoped>
.modal {
  background-color: rgba(0, 0, 0, 0.5);
}
</style>