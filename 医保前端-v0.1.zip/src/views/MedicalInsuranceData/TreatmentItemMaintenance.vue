<template>
  <div>
    <h2>诊疗项目数据维护</h2>
    <div class="d-flex justify-content-between mb-3">
      <div class="d-flex">
        <input type="text" class="form-control" placeholder="按项目名称搜索..." v-model="searchQuery">
        <button class="btn btn-primary ms-2" @click="fetchItems">搜索</button>
      </div>
      <button class="btn btn-success" @click="openAddModal">新增项目</button>
    </div>

    <table class="table table-striped">
      <thead>
        <tr>
          <th>项目编码</th>
          <th>项目名称</th>
          <th>价格</th>
          <th>备注</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in items" :key="item.id">
          <td>{{ item.code }}</td>
          <td>{{ item.name }}</td>
          <td>{{ item.price }}</td>
          <td>{{ item.remark }}</td>
          <td>
            <button class="btn btn-sm btn-warning me-2" @click="openEditModal(item)">修改</button>
            <button class="btn btn-sm btn-danger" @click="handleDeleteItem(item.id)">删除</button>
          </td>
        </tr>
      </tbody>
    </table>

    <div v-if="showModal" class="modal fade show d-block" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">{{ isEditMode ? '修改项目' : '新增项目' }}</h5>
            <button type="button" class="btn-close" @click="closeModal"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="handleSaveItem">
              <div class="mb-3">
                <label class="form-label">项目编码</label>
                <input type="text" class="form-control" v-model="currentItem.code" required>
              </div>
              <div class="mb-3">
                <label class="form-label">项目名称</label>
                <input type="text" class="form-control" v-model="currentItem.name" required>
              </div>
              <div class="mb-3">
                <label class="form-label">价格</label>
                <input type="number" class="form-control" v-model="currentItem.price" required>
              </div>
              <div class="mb-3">
                <label class="form-label">备注</label>
                <textarea class="form-control" v-model="currentItem.remark"></textarea>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" @click="closeModal">关闭</button>
                <button type="submit" class="btn btn-primary">保存</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from '@/api';

export default {
  name: 'TreatmentItemMaintenance',
  data() {
    return {
      searchQuery: '',
      items: [],
      showModal: false,
      isEditMode: false,
      currentItem: {
        id: null,
        code: '',
        name: '',
        price: 0,
        remark: ''
      },
    };
  },
  created() {
    this.fetchItems();
  },
  methods: {
    async fetchItems() {
      try {
        const response = await api.get('/treatment-items', {
          params: { name: this.searchQuery }
        });
        this.items = response.data;
      } catch (error) {
        console.error('获取诊疗项目列表失败:', error);
        alert('获取诊疗项目列表失败');
      }
    },
    openAddModal() {
      this.isEditMode = false;
      this.currentItem = { id: null, code: '', name: '', price: 0, remark: '' };
      this.showModal = true;
    },
    openEditModal(item) {
      this.isEditMode = true;
      this.currentItem = { ...item };
      this.showModal = true;
    },
    closeModal() {
      this.showModal = false;
    },
    async handleSaveItem() {
      try {
        if (this.isEditMode) {
          await api.put(`/treatment-items/${this.currentItem.id}`, this.currentItem);
        } else {
          await api.post('/treatment-items', this.currentItem);
        }
        this.closeModal();
        this.fetchItems();
      } catch (error) {
        console.error('保存诊疗项目失败:', error);
        alert('保存诊疗项目失败');
      }
    },
    async handleDeleteItem(id) {
      if (confirm('确定要删除该项目吗？')) {
        try {
          await api.delete(`/treatment-items/${id}`);
          this.fetchItems();
        } catch (error) {
          console.error('删除诊疗项目失败:', error);
          alert('删除诊疗项目失败');
        }
      }
    },
  },
};
</script>

<style scoped>
.modal {
  background-color: rgba(0, 0, 0, 0.5);
}
</style>