<template>
  <div>
    <h2>药品报销比例维护</h2>
    <form @submit.prevent="handleUpdateRatios">
      <table class="table table-striped">
        <thead>
          <tr>
            <th>药品类别</th>
            <th>报销比例 (%)</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="ratio in ratios" :key="ratio.id">
            <td>{{ ratio.category }}</td>
            <td>
              <input type="number" class="form-control" v-model.number="ratio.ratio" min="0" max="100">
            </td>
          </tr>
        </tbody>
      </table>
      <button type="submit" class="btn btn-primary">更新比例</button>
    </form>
  </div>
</template>

<script>
import api from '@/api';

export default {
  name: 'DrugReimbursementRatioMaintenance',
  data() {
    return {
      ratios: [],
    };
  },
  created() {
    this.fetchRatios();
  },
  methods: {
    async fetchRatios() {
      try {
        const response = await api.get('/drug-reimbursement-ratios');
        this.ratios = response.data;
      } catch (error) {
        console.error('获取药品报销比例失败:', error);
        alert('获取药品报销比例失败');
      }
    },
    async handleUpdateRatios() {
      try {
        await api.put('/drug-reimbursement-ratios', this.ratios);
        alert('更新成功');
        this.fetchRatios();
      } catch (error) {
        console.error('更新药品报销比例失败:', error);
        alert('更新药品报销比例失败');
      }
    },
  },
};
</script>

<style scoped>
</style>