<template>
  <div class="home">
    <h1>欢迎来到医疗保险报销系统</h1>
    <p>请使用左侧导航栏进行操作。</p>
  </div>
</template>

<script>
export default {
  name: 'HomePage'
}
</script>

<style scoped>
.home {
  padding: 20px;
}
</style>