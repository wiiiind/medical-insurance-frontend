<template>
  <div>
    <h2>患者诊断</h2>
    <div class="row">
      <!-- Patient List -->
      <div class="col-md-4">
        <h3>患者列表</h3>
        <div class="d-flex mb-2">
          <input type="text" class="form-control" placeholder="搜索患者..." v-model="patientSearchQuery">
          <button class="btn btn-primary ms-2" @click="fetchPatients">搜索</button>
        </div>
        <ul class="list-group">
          <li v-for="patient in patients" :key="patient.id" 
              class="list-group-item" 
              :class="{ active: selectedPatient && selectedPatient.id === patient.id }"
              @click="selectPatient(patient)">
            {{ patient.name }}
          </li>
        </ul>
      </div>

      <!-- Diagnosis Section -->
      <div class="col-md-8" v-if="selectedPatient">
        <h3>为 {{ selectedPatient.name }} 添加诊断</h3>
        <div class="mb-3">
          <label class="form-label">诊断类型</label>
          <select class="form-select" v-model="diagnosis.type">
            <option value="入院诊断">入院诊断</option>
            <option value="主要诊断">主要诊断</option>
            <option value="其他诊断">其他诊断</option>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">选择疾病</label>
          <div class="d-flex">
            <input type="text" class="form-control" placeholder="搜索疾病..." v-model="diseaseSearchQuery">
            <button class="btn btn-primary ms-2" @click="fetchDiseases">搜索</button>
          </div>
          <select class="form-select mt-2" v-model="diagnosis.disease_id">
            <option v-for="disease in diseases" :key="disease.id" :value="disease.id">
              {{ disease.name }}
            </option>
          </select>
        </div>
        <button class="btn btn-primary" @click="handleAddDiagnosis">添加诊断</button>
      </div>
    </div>
  </div>
</template>

<script>
import api from '@/api';

export default {
  name: 'PatientDiagnosis',
  data() {
    return {
      patients: [],
      diseases: [],
      selectedPatient: null,
      patientSearchQuery: '',
      diseaseSearchQuery: '',
      diagnosis: {
        type: '入院诊断',
        disease_id: null,
      },
    };
  },
  created() {
    this.fetchPatients();
    this.fetchDiseases();
  },
  methods: {
    async fetchPatients() {
      try {
        const response = await api.get('/patients', { params: { name: this.patientSearchQuery } });
        this.patients = response.data;
      } catch (error) {
        console.error('获取患者列表失败:', error);
      }
    },
    async fetchDiseases() {
      try {
        const response = await api.get('/diseases', { params: { name: this.diseaseSearchQuery } });
        this.diseases = response.data;
      } catch (error) {
        console.error('获取疾病列表失败:', error);
      }
    },
    selectPatient(patient) {
      this.selectedPatient = patient;
    },
    async handleAddDiagnosis() {
      if (!this.selectedPatient || !this.diagnosis.disease_id) {
        alert('请选择患者和疾病');
        return;
      }
      try {
        await api.post(`/patients/${this.selectedPatient.id}/diagnoses`, this.diagnosis);
        alert('添加诊断成功');
        this.diagnosis.disease_id = null; // Reset form
      } catch (error) {
        console.error('添加诊断失败:', error);
        alert('添加诊断失败');
      }
    },
  },
};
</script>

<style scoped>
.list-group-item {
  cursor: pointer;
}
</style>