<template>
  <div>
    <h2>入院登记</h2>
    <form @submit.prevent="handleRegister">
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">姓名</label>
          <input type="text" class="form-control" v-model="patient.name" required>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">身份证号</label>
          <input type="text" class="form-control" v-model="patient.id_card" required>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">性别</label>
          <select class="form-select" v-model="patient.gender">
            <option value="男">男</option>
            <option value="女">女</option>
          </select>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">出生日期</label>
          <input type="date" class="form-control" v-model="patient.birth_date">
        </div>
      </div>
      <div class="mb-3">
        <label class="form-label">家庭住址</label>
        <input type="text" class="form-control" v-model="patient.address">
      </div>
      <button type="submit" class="btn btn-primary">登记</button>
    </form>
  </div>
</template>

<script>
import api from '@/api';

export default {
  name: 'AdmissionRegistration',
  data() {
    return {
      patient: {
        name: '',
        id_card: '',
        gender: '男',
        birth_date: '',
        address: ''
      },
    };
  },
  methods: {
    async handleRegister() {
      try {
        await api.post('/patients', this.patient);
        alert('入院登记成功');
        // Reset form
        this.patient = {
          name: '',
          id_card: '',
          gender: '男',
          birth_date: '',
          address: ''
        };
      } catch (error) {
        console.error('入院登记失败:', error);
        alert('入院登记失败');
      }
    },
  },
};
</script>

<style scoped>
</style>