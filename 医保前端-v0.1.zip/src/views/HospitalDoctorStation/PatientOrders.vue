<template>
  <div>
    <h2>患者医嘱</h2>
    <div class="row">
      <!-- Patient List -->
      <div class="col-md-4">
        <h3>患者列表</h3>
        <div class="d-flex mb-2">
          <input type="text" class="form-control" placeholder="搜索患者..." v-model="patientSearchQuery">
          <button class="btn btn-primary ms-2" @click="fetchPatients">搜索</button>
        </div>
        <ul class="list-group">
          <li v-for="patient in patients" :key="patient.id"
              class="list-group-item"
              :class="{ active: selectedPatient && selectedPatient.id === patient.id }"
              @click="selectPatient(patient)">
            {{ patient.name }}
          </li>
        </ul>
      </div>

      <!-- Order Section -->
      <div class="col-md-8" v-if="selectedPatient">
        <h3>为 {{ selectedPatient.name }} 添加医嘱</h3>
        <div class="mb-3">
          <label class="form-label">医嘱类型</label>
          <select class="form-select" v-model="order.type">
            <option value="药品处方">药品处方</option>
            <option value="诊疗项目">诊疗项目</option>
            <option value="医疗服务">医疗服务</option>
          </select>
        </div>

        <!-- Item Selection -->
        <div class="mb-3">
          <label class="form-label">选择项目</label>
          <div v-if="order.type === '药品处方'">
            <select class="form-select" v-model="order.item_id">
              <option v-for="drug in drugs" :key="drug.id" :value="drug.id">{{ drug.name }}</option>
            </select>
          </div>
          <div v-if="order.type === '诊疗项目'">
            <select class="form-select" v-model="order.item_id">
              <option v-for="item in treatmentItems" :key="item.id" :value="item.id">{{ item.name }}</option>
            </select>
          </div>
          <div v-if="order.type === '医疗服务'">
            <select class="form-select" v-model="order.item_id">
              <option v-for="service in medicalServices" :key="service.id" :value="service.id">{{ service.name }}</option>
            </select>
          </div>
        </div>
        <button class="btn btn-primary" @click="handleAddOrder">添加医嘱</button>
      </div>
    </div>
  </div>
</template>

<script>
import api from '@/api';

export default {
  name: 'PatientOrders',
  data() {
    return {
      patients: [],
      drugs: [],
      treatmentItems: [],
      medicalServices: [],
      selectedPatient: null,
      patientSearchQuery: '',
      order: {
        type: '药品处方',
        item_id: null,
      },
    };
  },
  created() {
    this.fetchPatients();
    this.fetchOrderItems();
  },
  methods: {
    async fetchPatients() {
      try {
        const response = await api.get('/patients', { params: { name: this.patientSearchQuery } });
        this.patients = response.data;
      } catch (error) {
        console.error('获取患者列表失败:', error);
      }
    },
    async fetchOrderItems() {
      try {
        const [drugsRes, itemsRes, servicesRes] = await Promise.all([
          api.get('/drugs'),
          api.get('/treatment-items'),
          api.get('/medical-services'),
        ]);
        this.drugs = drugsRes.data;
        this.treatmentItems = itemsRes.data;
        this.medicalServices = servicesRes.data;
      } catch (error) {
        console.error('获取医嘱项目失败:', error);
      }
    },
    selectPatient(patient) {
      this.selectedPatient = patient;
    },
    async handleAddOrder() {
      if (!this.selectedPatient || !this.order.item_id) {
        alert('请选择患者和医嘱项目');
        return;
      }
      try {
        await api.post(`/patients/${this.selectedPatient.id}/orders`, this.order);
        alert('添加医嘱成功');
        this.order.item_id = null; // Reset form
      } catch (error) {
        console.error('添加医嘱失败:', error);
        alert('添加医嘱失败');
      }
    },
  },
};
</script>

<style scoped>
.list-group-item {
  cursor: pointer;
}
</style>